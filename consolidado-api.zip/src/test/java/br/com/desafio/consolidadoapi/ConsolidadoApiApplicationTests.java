package br.com.desafio.consolidadoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsolidadoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
