package br.com.desafio.lancamentosapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LancamentosApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
